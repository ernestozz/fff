/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traer.datos;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author medrano
 */
public class Sentencias implements AccionesDB{

    private String cod;
    private String nombre;
    private String nombre1;
    private String pregunta1;

    public String getPregunta1() {
        return pregunta1;
    }

    public void setPregunta1(String pregunta1) {
        this.pregunta1 = pregunta1;
    }
   
    
    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }
    
     public void insetarDB(){
      
    ConexionMySQL conexion = new ConexionMySQL();
      
      Connection conn = conexion.getConexion();
      Statement st;
      
      String sql = "insert into usuario(nombre, nombre1, pregunta1)" +
              " values('"+getNombre() + "','" + getNombre1()+ "','" +getPregunta1() +"')";
      
      try {
      st = conn.createStatement();
      
      st.executeUpdate(sql);
      conn.close();
      st.close();
      
      }catch(SQLException e){
          e.printStackTrace();
      }
     }
    
     public void selectDB(){
       ConexionMySQL conexion = new ConexionMySQL();
      
       Connection conn = conexion.getConexion();
       Statement st;
       
        String sql = "SELECT * FROM usuario where id_nombre=" + this.getCod();
        
        try{
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
            
                this.setNombre(rs.getString(2));
                this.setNombre1(rs.getString(3));    
                this.setPregunta1(rs.getString(4));  
            }
            conn.close();
            st.close();   
            
        }catch(SQLException e){
          e.printStackTrace();
      }
  }
   
     public void UpdateDB(){
       ConexionMySQL conexion = new ConexionMySQL();
      
       Connection conn = conexion.getConexion();
       Statement st;
       
        String sql = "SELECT * FROM usuario where id_nombre=" + this.getCod();
        
        try{
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
            
                this.setNombre(rs.getString(2));
                this.setNombre1(rs.getString(3));      
                this.setPregunta1(rs.getString(4));
            }
            conn.close();
            st.close();   
            
        }catch(SQLException e){
          e.printStackTrace();
      }
  }
     
  public DefaultTableModel actualizarTabla(){
      
      DefaultTableModel modelo = new DefaultTableModel();
      modelo.addColumn("id");
      modelo.addColumn("Nombre");
      modelo.addColumn("Nombre1");
      modelo.addColumn("Pregunta11");
      
       ConexionMySQL conexion = new ConexionMySQL();
       Connection conn = conexion.getConexion();
       
       Statement st;
       
       String sql = "SELECT * FROM usuario";
       
       String[] datos = new String[4];
       
       try{
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()){
                
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                
                modelo.addRow(datos);               
            }
            conn.close();
            st.close();
       }catch(SQLException e){
          e.printStackTrace();
      }
       return modelo;
      
  }

    @Override
    public void insertarDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actualizarDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminarDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
