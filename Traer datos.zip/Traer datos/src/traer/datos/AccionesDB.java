/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traer.datos;

/**
 *
 * @author medrano
 */
public interface AccionesDB {
    
    public void insertarDB();
    public void selectDB();
    public void actualizarDB();
    public void eliminarDB();
}
